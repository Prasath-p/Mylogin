var res;
tableName = document.getElementById('name')
tablePassword = document.getElementById('psw')
function validateForm() {
   
    const message = document.getElementById("message");
  // console.log("test", email, password);
    // Replace with your email and password validation logic
    // For example, check if the email and password are not empty
    if (!email || !password) {
      message.textContent = "Please enter your email and password.";
      message.style.color = "red";
      return false;
    }
  
    // Add any other validation logic as needed
    // For example, you can use regular expressions to validate the email format
  
    return true;
  }

const form = document.querySelector('form')
form.addEventListener('submit', (e) => {
  e.preventDefault()
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  const obj = {email: email, password:password};
  const myJSON = JSON.stringify(obj);
  // console.log(myJSON);
  fetch("http://localhost:3000/v1/createEmployee", {
  method: "POST",
  body: myJSON,
  headers: {
    "Content-type": "application/json; charset=UTF-8"
  }
})
  .then((response) => response.json())
  .then((json) => {
    // console.log(json);
  });
})
details = [];
async function getDetails(id,email,password) {
  const response = await fetch("http://localhost:3000/v1/getEmployees");
  const obj = await response.json();
  const data = [];
  const tableBody = document.querySelector('#myTable tbody');
  for(let i=0; i<obj.response.length; i++){
    data.push(obj.response[i])
    // data.pop()
      }
    // console.log(data);
      const row = document.createElement('tr');
    
      const cell1 = document.createElement('td');
      cell1.textContent = email;
    
      const cell2 = document.createElement('td');
      cell2.textContent = password;
      
      const editCell = document.createElement('td');
      const editIcon = document.createElement('button');
      editIcon.textContent = 'Edit';
      editIcon.classList.add('edit-icon');
      editIcon.addEventListener('click', () => editRow(id,email,password)); // Call the editRow function on click
      editCell.appendChild(editIcon);
      
      const deleteCell = document.createElement('td');
      const deleteIcon = document.createElement('button');
      deleteIcon.textContent = 'Delete';
      deleteIcon.classList.add('delete-icon');
      deleteIcon.addEventListener('click', () => deleteRow(data,id,email,password)); // Call the deleteRow function on click
      deleteCell.appendChild(deleteIcon);
      
      // Append cells to the row
      row.appendChild(cell1);
      row.appendChild(cell2);
      row.appendChild(editCell);
      row.appendChild(deleteCell);
      
      // Append the row to the table body
      tableBody.appendChild(row);
      console.log("....",data);
    }
    // Function to edit a row in the table
    function editRow(id,email,password) {
      const Email = prompt('Enter Email:', email);
      const Password = prompt('Enter Password:', password);
      const obj = {id:id,email: Email, password:Password
      };
    const myJSON = JSON.stringify(obj);
  // console.log(myJSON);
    fetch("http://localhost:3000/v1/updateEmployee", {
    method: "POST",
    body: myJSON,
    headers: {
      "Content-type": "application/json; charset=UTF-8"
    }
})
  .then((response) => response.json())
        console.log(Email,Password);
      // }
      updateTable();
    }
    
    // Function to delete a row from the table
    function deleteRow(data,id,email,password) {
      let Alert = prompt('Are you sure you wat to delete this '+"#"+email + ' type "Yes"')
      console.log(Alert =='yes' || Alert =='YES' || Alert =='Yes' || Alert =='yEs' || Alert =='yeS' || Alert =='yES' || Alert =='YeS' || Alert =='YEs');
      if(Alert){
        const obj = {id:id,email: email, password:password
        };
      const myJSON = JSON.stringify(obj);
    // console.log(myJSON);
      fetch("http://localhost:3000/v1/deleteEmployee", {
      method: "POST",
      body: myJSON,
      headers: {
        "Content-type": "application/json; charset=UTF-8"
      }
      })
    .then((response) => response.json())
    alert('Data are Deleted')
        updateTable();
      }
      else{
        alert('Data are not Deleted')
      }
      }
    
    // Function to update the table based on the current 'data' array
    updateTable();
    async function updateTable() {
      const response = await fetch("http://localhost:3000/v1/getEmployees");
      const obj = await response.json();
      // console.log("....",obj);
      const data = [];
      const tableBody = document.querySelector('#myTable tbody');
      for(let i=0; i<obj.response.length; i++){
          data.push(obj.response[i])
          // data.pop()
          }
        // console.log(data);
      tableBody.innerHTML = '';
      data.forEach(item => getDetails(item.id, item.email, item.password));
    }
    
    // Initial table rendering
    updateTable();
    
  // Show/hide password functionality
  const togglePasswordButton = document.getElementById("togglePassword");
  const passwordInput = document.getElementById("password");
  
  togglePasswordButton.addEventListener("click", function () {
    const type = passwordInput.getAttribute("type") === "password" ? "text" : "password";
    passwordInput.setAttribute("type", type);
    this.innerHTML = type === "password" ? '<i class="fa fa-eye"></i>' : '<i class="fa fa-eye-slash"></i>';
  });
