'use strict';

// Define a model for role table
module.exports = (sequelize, DataTypes) => {
  var Model = sequelize.define('role', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false
    },
    password: {
      type:  DataTypes.STRING,
      // defaultValue: DataTypes.NOW,
      allowNull: false
    }
  }, {
    tableName: 'role'
  });
  // Adding a class level method.
  Model.associate = function (models) {
  };
  return Model;
};