const Employee  = require('../models').role;
const getEmployees = async function (req, res) {
  let err;
  // let response = { name: 'Boopathi' };
  console.log('getEmployees: ');
  [err, response] = await to(Employee.findAll());
  if (err) return ReE(res, err, 422);
  return ReS(res, { response });
}
module.exports.getEmployees = getEmployees;

const createEmployee = async function (req, res) {
  let err;
  let body = req.body;
  [err, response] = await to(Employee.create(body));
  console.log('createEmployee: ', body);
  if (err) return ReE(res, err, 422);
  return ReS(res, { response });
}
module.exports.createEmployee = createEmployee;

const deleteEmployee = async function (req, res) {
  let err;
  let body = req.body;
  [err, response] = await to(Employee.destroy({
    where:[
      {id : body.id }
    ]
  }));
  // console.log('createEmployee: ', body);
  if (err) return ReE(res, err, 422);
  return ReS(res, { response });
}
module.exports.deleteEmployee = deleteEmployee;


const updateEmployee = async function (req, res) {
  let err;
  let body = req.body;
  console.log(req.body);
  [err, response] = await to(Employee.update(body,{
    where:[
      {id : body.id }
    ]
  }));
  // console.log('createEmployee: ', body);
  if (err) return ReE(res, err, 422);
  return ReS(res, { response });
}
module.exports.updateEmployee = updateEmployee;