ERROR = {};
ERROR.password_notset = 'password not set';
ERROR.invalid_credentials = 'Invalid username or password, please try again';
ERROR.invalid_email = 'A valid email is not entered';

SUCCESS = {};
